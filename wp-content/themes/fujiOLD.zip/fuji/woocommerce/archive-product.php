<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
do_action( 'woocommerce_before_main_content' );

?>

<?php $term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy')); ?>

    <section class="my-4 container-xl px-4 px-lg-3 px-xxl-5">
      <div class="row">
        <h5 class="text-center">Search: "hammer" - 109 results</h5>
        <div class="col-lg-3">
          <div class="filters">
            <h5 class="mb-3">Work Tools</h5>

            <div class="accordion accordion-flush" id="accordionFlushExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#flush-collapseOne"
                    aria-expanded="false"
                    aria-controls="flush-collapseOne"
                  >
                    Air Tools
                  </button>
                </h2>
                <div
                  id="flush-collapseOne"
                  class="accordion-collapse collapse"
                  aria-labelledby="flush-headingOne"
                  data-bs-parent="#accordionFlushExample"
                >
                  <div class="accordion-body">
                    <div class="d-flex align-items-center">
                      <input
                        type="checkbox"
                        id="handHammar"
                        name="manufacturer1"
                        value=""
                      />
                      <label for="handHammar" class="mb-0 ms-2"
                        >Hand Hammars</label
                      >
                    </div>
                    <div class="d-flex align-items-center">
                      <input
                        type="checkbox"
                        id="ballPen"
                        name="manufacturer1"
                        value=""
                      />
                      <label for="ballPen" class="mb-0 ms-2"
                        >Ball Peen hammers</label
                      >
                    </div>
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingTwo">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#flush-collapseTwo"
                    aria-expanded="false"
                    aria-controls="flush-collapseTwo"
                  >
                    Drill Tools
                  </button>
                </h2>
                <div
                  id="flush-collapseTwo"
                  class="accordion-collapse collapse"
                  aria-labelledby="flush-headingTwo"
                  data-bs-parent="#accordionFlushExample"
                >
                  <div class="accordion-body">
                    <div class="d-flex align-items-center mb-1">
                      <input
                        type="checkbox"
                        id="pixiee"
                        name="manufacturer"
                        value=""
                      />
                      <label for="pixiee" class="mb-0 ms-2">Pixiee</label>
                    </div>
                    <div class="d-flex align-items-center mb-1">
                      <input
                        type="checkbox"
                        id="dewalt"
                        name="manufacturer"
                        value=""
                      />
                      <label for="dewalt" class="mb-0 ms-2">Dewalt</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
           
            <hr />
            
          </div>
        </div>
        <div class="col-lg-9">
          
          <div
            class="
              d-flex
              mt-2
              mb-lg-3
              gap-2
              justify-content-between
              filter-options
            "
          >
            <div class="d-flex">
              <select class="form-select rounded-0 p-1" aria-label="Default select example">
                <option selected>Sort By:</option>
                <option value="1">Name: A - Z</option>
                <option value="1">Name: Z - A</option>
                <option value="2">Price: High to Low</option>
                <option value="2">Price: Low to High</option>
              </select>
            </div>
            <button class="btn btn-light d-block d-lg-none filter-btn">
              Filters
            </button>

            <div class="product-view-options">
              <button class="btn list-btn active">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="22"
                  height="22"
                  fill="currentColor"
                  class="bi bi-list-ul"
                  viewBox="0 0 16 16"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"
                  />
                </svg>
              </button>
              <button class="btn grid-btn">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  fill="currentColor"
                  class="bi bi-grid-3x3-gap-fill"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M1 2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V2zM1 7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V7zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V7zM1 12a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-2z"
                  />
                </svg>
              </button>
            </div>
          </div>
          <div class="row g-3 mb-5">
            <!-- loop starts -->
            <?php
              $counter = 1;
              ?>
              <?php if (have_posts()) :
                while (have_posts()) : the_post();?>
                    <div class="col-12 search-item">
                      <a class="text-dark" href="<?php the_permalink();?>">
                        <figure class="border border-secondary mb-0 p-1 d-none">
                          <img
                            class="search-item-img w-100 img-fluid obj-fit-cover"
                            src="<?php the_post_thumbnail_url(); ?>"
                            alt="<?php the_title();?>"
                          />
                        </figure>
                        <div class="px-0 px-lg-2 border-bottom">
                          <h5 class="title">
                          <?php the_title();?>
                          </h5>
                          <h5>
                            <?php  //echo get_post_meta(get_the_ID(), '_regular_price', true);
                          $_product = wc_get_product( get_the_ID() );
                          echo $_product->get_price_html();
                          ?>
                          </h5>
                        </div>
                      </a>
                    </div>
            <?php $counter++;
            endwhile;
            endif; ?>
          </div>
        </div>
      </div>
    </section>

<?php

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'woocommerce_after_main_content' );

/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10
 */
// do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );