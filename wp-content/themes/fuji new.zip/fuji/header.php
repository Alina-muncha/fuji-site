<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package fuji
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'fuji' ); ?></a>

  <header class="bg-dark d-flex flex-row-reverse flex-direction-row">
      <!-- <div class="dropdown rounded-0">
        <button
          class="btn btn-dark btn-sm dropdown-toggle rounded-0"
          type="button"
          id="dropdownMenuButton1"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <img class="img-flag" src="../assets/img/japan.png" />
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li>
            <a class="dropdown-item d-flex justify-content-between" href="#"
              >Japan<img class="img-flag" src="../assets/img/japan.png"
            /></a>
          </li>
          <li>
            <a
              class="dropdown-item d-flex justify-content-between"
              href="./product.html"
              >English <img class="img-flag" src="../assets//img/uk.png"
            /></a>
          </li>
        </ul>
      </div> -->
      
      <?php echo do_shortcode('[language-switcher]'); ?>
      
      <div class="text-white me-4 text-small">
        <p class="mb-0">
        <?php if(get_locale() == 'ja') { 
                    echo "いらっしゃいませ、";
                  }
                    else{
                      echo "Welcome,";
                      }
                ?>  
       </p>
        <p class="mb-0">
        <?php if(get_locale() == 'ja') { 
                    echo "管理者";
                  }
                    else{
                      echo "Admin";
                      }
                ?>
        </p>
      </div>
    </header>

     <!-- Navbar -->
     <nav
      class="
        navbar navbar-expand-lg navbar-dark
        bg-primary
        position-sticky
        top-0
        z-index-2
        p-lg-0
      "
    >
      <div class="container-xl px-3 px-xxl-5">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- For Small Device -->
        <div class="d-flex d-lg-none">
          <button
            type="button"
            class="btn text-white"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              fill="currentColor"
              class="bi bi-search"
              viewBox="0 0 16 16"
            >
              <path
                d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"
              />
            </svg>
          </button>
          <button class="btn text-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              fill="currentColor"
              class="bi bi-person"
              viewBox="0 0 16 16"
            >
              <path
                d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"
              />
            </svg>
          </button>
          <button class="btn text-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              fill="currentColor"
              class="bi bi-bag"
              viewBox="0 0 16 16"
            >
              <path
                d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"
              />
            </svg>
          </button>
        </div>

        <div
          class="collapse navbar-collapse justify-content-between"
          id="navbarSupportedContent"
        >
          <div
            class="d-none d-lg-flex flex-direction-column align-items-center"
          >
            <a class="navbar-brand" href="<?php echo get_site_url();?>">
              <div class="">
                <img class="img-fluid logo" src="<?php the_field('logo', 'options')?>" />
                <h6 class="mb-0">
                  <?php if(get_locale() == 'ja') { 
                    echo "富士、企業間ストア";
                  }
                    else{
                      echo  "FUJI B2B STORE";}
                      ?>
              </h6>
              </div>
            </a>
          </div>
          <?php wp_nav_menu( array( 'theme_location' => 'menu-1', 'menu_id' => 'primary-menu', 'container' => 'ul','menu_class' => 'nav-link nav-item navbar-nav mb-2 mb-lg-0', 'walker' => new macho_bootstrap_walker) ); ?>

          <!-- <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="#">HOME</a>
            </li>
            <li class="nav-item dropdown has-megamenu">
              <a
                class="nav-link"
                href="#"
                type="button"
                id="dropdownMenuButton1"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                CATEGORIES
              </a>
              <div
                class="dropdown-menu megamenu rounded-0 border-0"
                role="menu"
              >
                <div class="container-xl py-lg-3">
                  <div class="row">
                    <ul class="list-group col-md-3">
                      <li
                        class="
                          list-group-item
                          border-0
                          p-1
                          hoverable-item
                          bg-transparent
                        "
                      >
                        <a class="text-muted" href="#">Paints</a>
                      </li>
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Tape</a>
                      </li>
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Building Materials</a>
                      </li>
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Adhesives</a>
                      </li>
                    </ul>
                    <ul class="list-group col-md-3">
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Work Tools</a>
                      </li>
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Cleaning</a>
                      </li>
                      <li class="list-group-item border-0 p-1 hoverable-item">
                        <a class="text-muted" href="#">Plastic Materials</a>
                      </li>
                    </ul>
                    <div class="col-md-4 d-none d-lg-block">
                      <a href="#">
                        <div class="border">
                          <figure
                            class="
                              megamenu-item
                              m-0
                              overflow-hidden
                              scalable
                              position-relative
                            "
                          >
                            <img
                              class="h-100 w-100 obj-fit-cover"
                              src="https://cdn.shopify.com/s/files/1/0448/0765/1493/files/ban_33_2_380x240_crop_center.png?v=1596019262"
                            />
                            <div class="caption px-4 mt-4">
                              <h5 class="text-dark">Abrasive</h5>
                            </div>
                          </figure>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">FAVOURITES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">CONTACT US</a>
            </li>
          </ul> -->
          <ul class="navbar-nav mb-2 mb-lg-0 d-none d-lg-flex">
            <li class="nav-item">
              <button
                type="button"
                class="btn text-white"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
              >
                <span class="me-2"> 
                <?php if(get_locale() == 'ja') { 
                    echo "検索";
                  }
                    else{
                      echo "Search Here";
                      }
                ?>
                </span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  fill="currentColor"
                  class="bi bi-search"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"
                  />
                </svg>
              </button>
            </li>
            <li class="nav-item">
              <button class="btn text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  fill="currentColor"
                  class="bi bi-person"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"
                  />
                </svg>
              </button>
            </li>
            <li class="nav-item">
              <div class="dropdown hoverable-dropdown">
                <div class="position-relative">
                  <a
                    class="nav-link text-white"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      fill="currentColor"
                      class="bi bi-bag"
                      viewBox="0 0 16 16"
                    >
                      <path
                        d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"
                      />
                    </svg>
                  </a>
                  <span
                    class="
                      badge
                      bg-dark
                      position-absolute
                      top-0
                      start-100
                      translate-middle
                    "
                    >4</span
                  >
                </div>

                <!-- <a class="nav-link dropdown active" aria-current="page" href="#">HOME</a> -->
                <div
                  class="
                    dropdown-menu
                    cart-dropdown-menu
                    rounded-0
                    py-3
                    px-4
                    border-0
                    elevate-1
                  "
                  aria-labelledby="dropdownMenuLink"
                >
                  <div class="row">
                    <div class="row border-bottom">
                      <div class="col-6">
                        <img
                          class="img-fluid text-center"
                          src="https://cdn.shopify.com/s/files/1/0448/0765/1493/products/makita-lxt601-18-volt-lxt-6-piece-lithium-ion-cordless-combo-kit_1_140x140_crop_center.png?v=1595925419"
                        />
                      </div>
                      <div class="col-6">
                        <a class="text-dark" href="#">
                          <div class="text-truncate">
                            Praeterea iter est quasdam res quas ex communi.
                          </div>
                        </a>
                        <p class="fw-bold mb-1">¥ 120.00</p>
                        <p class="text-muted mb-1">Quantity: 1</p>
                        <h6 class="text-end">
                          <button class="btn hoverable-btn">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              fill="currentColor"
                              class="bi bi-trash"
                              viewBox="0 0 16 16"
                            >
                              <path
                                d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"
                              />
                              <path
                                fill-rule="evenodd"
                                d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"
                              />
                            </svg>
                          </button>
                        </h6>
                      </div>
                    </div>

                    <div class="row border-bottom">
                      <div class="col-6 text-center">
                        <img
                          class="img-fluid"
                          src="https://cdn.shopify.com/s/files/1/0448/0765/1493/products/makita-lxt601-18-volt-lxt-6-piece-lithium-ion-cordless-combo-kit_1_140x140_crop_center.png?v=1595925419"
                        />
                      </div>
                      <div class="col-6">
                        <a class="text-dark" href="#">
                          <div class="text-truncate">
                            Praeterea iter est quasdam res quas ex communi.
                          </div>
                        </a>
                        <p class="fw-bold mb-1">¥ 120.00</p>
                        <p class="text-muted mb-1">Quantity: 1</p>
                        <h6 class="text-end">
                          <button class="btn hoverable-btn">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              fill="currentColor"
                              class="bi bi-trash"
                              viewBox="0 0 16 16"
                            >
                              <path
                                d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"
                              />
                              <path
                                fill-rule="evenodd"
                                d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"
                              />
                            </svg>
                          </button>
                        </h6>
                      </div>
                    </div>

                    <div class="d-flex my-2">
                      <div class="d-flex align-items-end">
                        <a href="#" class="text-muted"
                          ><span class="me-5">Clear Cart</span></a
                        >
                      </div>
                      <div class="mx-auto">
                        <span>
                        <?php if(get_locale() == 'ja') { 
                            echo "合計金額：";
                          }
                            else{
                              echo "Total Price: ";
                              }
                        ?>  
                        </span>
                        <span class="h3"> ¥ 200.00</span>
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-6 text-center">
                        <a
                          href="#"
                          class="btn btn-outline-warning rounded-0 px-5"
                        >
                        <?php if(get_locale() == 'ja') { 
                            echo "チェックアウト";
                          }
                            else{
                              echo "Checkout";
                              }
                        ?>
                        </a>
                      </div>
                      <div class="col-6">
                        <a
                          href="#"
                          class="btn btn-warning text-white rounded-0 px-5"
                        >
                          
                        <?php if(get_locale() == 'ja') { 
                    echo "カートに移動";
                  }
                    else{
                      echo "Go to cart";
                      }
                ?>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>   
  